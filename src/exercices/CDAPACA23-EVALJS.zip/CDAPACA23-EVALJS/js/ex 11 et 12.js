/*
11. Créez un tableau et ajoutez y 6 valeurs dont :
	- Un booléen
	- Un entier (integer)
	- Un nombre à virgule (float)
	- Une chaîne de caractère (string)
*/


/*
12. Créez un objet appelé « personnage » et ajoutez-y les propriétés suivantes :
	- Son prénom doit être « Jean-Louis »
	- Son nom doit être « Errante »
	- Son âge doit petre « 35 »
	- Sa taille doit être 174
*/