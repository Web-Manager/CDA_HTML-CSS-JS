// 1. Initialiser la variable poney, assignez lui la valeur : poly

// 2. Initialiser la variable evaluation, assignez lui une valeur numérique au hasard (à vous de choisir la valeur)

//  3. Définissez une variable qui ne pourra pas changer par la suite, quoi qu'il arrive
 
// 4. Quelle est la syntaxe d'une condition ? (ecrivez une condition)

// 5. Quelle est la syntaxe d'un switch ? (ecrivez un switch)

// 6. Quelle est la syntaxe d'une boucle for ? (ecrivez un for)

// 7. Quelle est la syntaxe d'une boucle while ? (ecrivez un while)
