/*
	Ecrivez le JS nécessaire pour reproduire sur votre page web,
	ce qui se trouve sur le document JS Evaluation.pdf
	pour l'exercice 9

*/