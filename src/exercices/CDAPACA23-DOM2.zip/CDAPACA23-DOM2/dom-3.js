/*
    Ecrivez un code HTML + JS qui permet :

    De demander à l'utilisateur d'entrer deux nombres différents
    Inversez les deux valeurs
    Afficher à l'utilisateur :
        - La valeur A = (valeur A) et la valeur B = (valeur B)
    Puis ensuite afficher dessous :
        - La valeur A est maintenant égale à (valeur A) et la valeur B est maintenant égale à (valeur B)

*/