/*
    Ecrivez un code HTML + JS qui permet :

    De demander à l'utilisateur d'entrer un nombre
    Vous devez ensuite afficher la table de multiplication (jusqu'à 10) de ce nombre
*/