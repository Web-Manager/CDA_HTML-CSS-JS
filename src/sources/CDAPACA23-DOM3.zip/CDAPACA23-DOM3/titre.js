/*
    Ecrivez un script qui permet de modifier le h1 de la page
    Ecrivez un script qui permet d'ajouter un paragraphe après ce h1

*/