/*
    Ecrivez un programme pour permettre à l'utilisateur d'entrer un temps
    en seconde, et le convertir en minutes.

    La conversion doit s'afficher sur la page HTML dans la div avec l'id convert
    Vous devez afficher la conversion sous cette forme : 
        xx secondes est égal à x minute

    Contraintes : 
        Vous devez prendre en compte :
            - D'afficher seconde au singulier s'il n'y a qu'une seconde
            - D'afficher seconde au pluriel s'il y a plus d'une seconde
            - D'afficher minute au singulier s'il n'y a qu'une minute
            - D'afficher minute au pluriel s'il y a plus d'une minute
*/