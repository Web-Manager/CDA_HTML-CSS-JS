/*
    Ecrivez un programme qui permet d'ajouter une note à un élève.
    Pour cela vous devez utiliser :
        - Un tableau JavaScript
        - La méthode push() pour les tableaux
        - L'écouteur d'évènement au click

    Chaque note que vous ajoutez doivent être ajoutée sur la page HTML
    dans le tableau prévu à cet effet
*/