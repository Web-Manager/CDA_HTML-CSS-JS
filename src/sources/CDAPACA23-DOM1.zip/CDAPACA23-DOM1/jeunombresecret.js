/*
    Développez le jeu pour découvrir le nombre secret.
    Cette fois-ci, vous devez laisser le joueur choisir le nombre.

    A chaque nombre choisi, vous devez afficher : Plus grand, plus petit, gagné ou perdu selon les cas.

    Le joueur n'a le droit qu'à 10 essai.

    Vous devez afficher et laisser choisir le joueur directement sur la page HTML

*/